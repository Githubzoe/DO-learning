### Use with Opsgenie

Example:

```
 terraformer import opsgenie --resources=team,user --api-key=YOUR_API_KEY // or OPSGENIE_API_KEY in env
```

List of supported Opsgenie services:

*   `team`
    * `opsgenie_team`
*   `user`
    * `opsgenie_user`
