# EKS Cluster Auto Scaling (Kubernetes Autoscaler | EKS Cluster Autoscaler | EKS Autoscale Nodes)

[YouTube Tutorial](https://youtu.be/gwmdboC-BtE)
