export class CreateBookDto {}
