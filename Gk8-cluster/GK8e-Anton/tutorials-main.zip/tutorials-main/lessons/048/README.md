# How to Test Lambda Container Images?

[YouTube Tutorial](https://antonputra.com/how-to-test-lambda-container-images/)
