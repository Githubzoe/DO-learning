# How to Install Prometheus on Kubernetes Cluster?

[YouTube Tutorial](https://antonputra.com/how-to-install-prometheus-on-kubernetes-cluster/)
